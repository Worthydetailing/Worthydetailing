import React from "react";

function App() {
  return (
    <div className="min-h-screen bg-gray-900 text-gray-100">
      <header className="bg-black text-white p-6 text-center shadow-md">
        <h1 className="text-4xl font-bold">Worthy Detailing</h1>
        <p className="text-lg mt-2">Premium Car Detailing in Narre Warren, VIC</p>
      </header>

      <section className="p-8 bg-gray-800">
        <h2 className="text-3xl font-semibold mb-6 text-center">Our Services</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {["Exterior Detailing","Interior Detailing","Paint Correction","Ceramic Coating","Headlight Restoration","Engine Bay Cleaning"].map(service => (
            <div key={service} className="bg-gray-700 text-white p-4 rounded shadow">
              <h3 className="text-xl font-medium">{service}</h3>
            </div>
          ))}
        </div>
      </section>

      <section className="p-8 bg-gray-900">
        <h2 className="text-3xl font-semibold mb-4 text-center">About Us</h2>
        <p className="max-w-3xl mx-auto text-center text-lg text-gray-300">
          At Worthy Detailing, we take pride in restoring and protecting vehicles with precision and care. Based in Narre Warren, Melbourne, we offer top-tier services tailored to every car's needs.
        </p>
      </section>

      <section className="p-8 bg-gray-800">
        <h2 className="text-3xl font-semibold mb-6 text-center">Gallery</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-48 bg-gray-700 rounded-lg"></div>
          ))}
        </div>
      </section>

      <section className="p-8 bg-gray-900">
        <h2 className="text-3xl font-semibold mb-4 text-center">Contact Us</h2>
        <div className="max-w-xl mx-auto text-center text-lg space-y-4">
          <p>📞 0410 062 781</p>
          <p>📧 worthycarcare@gmail.com</p>
        </div>
      </section>

      <footer className="bg-black text-white text-center p-4 mt-6">
        &copy; 2025 Worthy Detailing. All rights reserved.
      </footer>
    </div>
  );
}

export default App;